package Coffe_Decorator;

public interface Coffee {
    double getCost();
    String getDescription();
}