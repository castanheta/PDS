package BehavioralPatterns.ex3;

public interface Figure {
    void accept(Visitor visitor);
}
