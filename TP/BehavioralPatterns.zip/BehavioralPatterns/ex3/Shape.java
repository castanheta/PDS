package BehavioralPatterns.ex3;

public interface Shape {
    void accept(Visitor visitor);
}